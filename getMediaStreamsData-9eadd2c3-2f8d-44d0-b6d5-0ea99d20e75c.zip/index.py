import boto3
import datetime
from pprint import pprint
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    pprint(event)
    contactId = event['Details']['ContactData']['ContactId'] # コンタクトID
    contactType = event['Details']['ContactData']['Attributes']['Type']
    customerEndpoint = event['Details']['ContactData']['CustomerEndpoint']['Address'] # 発信者番号
    systemEndpoint = event['Details']['ContactData']['SystemEndpoint']['Address'] # 着信番号

    startFragmentNumber = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StartFragmentNumber'] # 録音データの開始フラグメント番号
    startTimestamp = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StartTimestamp'] # 録音データの開始時間
    streamARN = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StreamARN'] # ストリームのARN
    
    
    # TODO implement
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('IVR_EVENT')
    now = datetime.datetime.now()

    try:
        if contactType == '2':
            closedTime = event['Details']['ContactData']['Attributes']['ClosedTime'] # セット時間
            response = table.put_item(
               Item={
                    'Date': now.strftime("%Y-%m-%d"),
                    'CustomerPhoneNumber': customerEndpoint,
                    'contactId': contactId,
                    'contactType': contactType,
                    'startFragmentNumber': startFragmentNumber,
                    'startTimestamp': startTimestamp,
                    'streamARN': streamARN,
                    'closedTime': closedTime
                }
            )
        else:
            response = table.put_item(
               Item={
                    'Date': now.strftime("%Y-%m-%d"),
                    'CustomerPhoneNumber': customerEndpoint,
                    'contactId': contactId,
                    'contactType': contactType,
                    'startFragmentNumber': startFragmentNumber,
                    'startTimestamp': startTimestamp,
                    'streamARN': streamARN
                }
            )
        pprint(response)
        statusCode = "200"
        resultMap = {"StatusCode":statusCode}  
        return resultMap
    except ClientError as ase:
        pprint(ase)
        statusCode = "300"
        resultMap = {"StatusCode":statusCode}  
        return resultMap
        